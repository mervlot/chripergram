import { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface Props {
  title: string;
  subtitle?: string;
  back?: boolean;
  children?: ReactNode;
  right?: ReactNode;
  left?: ReactNode;
  /** Overrides the default "go back in history" behaviour of the back arrow. */
  onBack?: () => void;
}

export function PageHeader({ title, subtitle, back, children, right, left, onBack }: Props) {
  const navigate = useNavigate();

  return (
    <div className="safe-top sticky top-0 z-20 border-b border-white/[0.07] bg-black/85 backdrop-blur-xl">
      <div className="flex min-h-14 items-center gap-3 px-4 py-2">
        {left}
        {back && (
          <button type="button" onClick={() => (onBack ? onBack() : navigate(-1))} className="icon-button" aria-label="Go back">
            <ArrowLeft size={19} />
          </button>
        )}
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-xl font-bold leading-tight tracking-tight text-white">
            {title}
          </h1>
          {subtitle && <p className="truncate text-xs font-semibold text-stone-500 dark:text-stone-500">{subtitle}</p>}
        </div>
        {right && <div className="shrink-0">{right}</div>}
      </div>
      {children}
    </div>
  );
}
