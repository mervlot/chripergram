import { useEffect, useState } from 'react';
import { ArrowUp } from 'lucide-react';

// Floating "back to top" button that appears once the page is scrolled down.
// Sits above the mobile bottom-nav / compose button.
export function ScrollToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  if (!visible) return null;

  return (
    <button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      aria-label="Scroll to top"
      className="animate-scale-in fixed bottom-[calc(env(safe-area-inset-bottom)+4.75rem)] right-4 z-30 flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-black/90 text-brand shadow-soft backdrop-blur transition active:scale-95 md:bottom-6"
    >
      <ArrowUp size={20} />
    </button>
  );
}
